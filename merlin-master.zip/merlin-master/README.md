Merlin
======
Free template with [Twitter Bootstrap](http://getbootstrap.com/) framework.

### Download

[https://github.com/halibegic/merlin/archive/master.zip](https://github.com/halibegic/merlin/archive/master.zip)

### Credits
 * [jQuery](http://jquery.com/)
 * [Tether](http://tether.io/)
 * [Bootstrap](http://getbootstrap.com/)
 * [Font Awesome](http://fortawesome.github.io/Font-Awesome/)
 * [Isotope](https://github.com/desandro/isotope)
 * [ImagesLoaded](https://github.com/desandro/imagesloaded)
 * [Animate.css](http://daneden.github.io/animate.css/)
 * [jQuery Scroll To](http://flesler.blogspot.com/2007/10/jqueryscrollto.html)
 * [jQuery One Page Nav](https://github.com/davist11/jQuery-One-Page-Nav)
 * [jQuery Appear](https://github.com/morr/jquery.appear)
 * [VenoBox](http://lab.veno.it/venobox/)
 * [Gratisography](http://www.gratisography.com/)

### Copyright and License

Copyright 2018 [Hasan Alibegić](https://halibegic.info/)

GNU General Public License v2 or later. [http://www.gnu.org/licenses/gpl-2.0.html](http://www.gnu.org/licenses/gpl-2.0.html)
